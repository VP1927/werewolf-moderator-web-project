import React from 'react';
import './App.css';

class Effect extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            history: [],
        }
    }

    componentDidMount() {
        let link = 'http://localhost:8080/effect/' + this.props.idcard;
        fetch(link)
            .then(response => response.json())
            .then(data => this.setState({ history: Array.from(data) }));
    }

    render() {
        const { effects } = this.state;
        console.log(this.props.idcard);
        if (!effects) return null;
        else
            return (
                <div>
                    <button></button>
                    <ul>
                        {effects.map(effect =>
                            <li key={effect.ideffect}>
                                <p>{effect.name}</p>
                            </li>)}
                    </ul>
                </div>
            );
    }
}

class NewApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cards: [],
        }
    }

    componentDidMount() {

        fetch('http://localhost:8080/cardlist')
            .then(response => response.json())
            .then(data => this.setState({ cards: data }))
    }

    render() {
        const cards = this.state.cards;

        if (!cards) return null;

        else return (
            <div>
                <ul>
                    {cards.map(card =>
                        <li key={card.idCard}>
                            <img src={card.imageLink}></img>
                            <Effect idcard={card.idCard} />
                        </li>)}
                </ul>
            </div>

        );
    }
}

export default NewApp;
